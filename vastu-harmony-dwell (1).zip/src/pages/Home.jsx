import Navbar from '@/components/Navbar';
import MandalaBackground from '@/components/MandalaBackground';
import Hero from '@/components/Hero';
import About from '@/components/About';
import WhyChoose from '@/components/WhyChoose';
import Services from '@/components/Services';
import Gallery from '@/components/Gallery';
import BookSection from '@/components/BookSection';
import Testimonials from '@/components/Testimonials';
import ContactForm from '@/components/ContactForm';
import CTABanner from '@/components/CTABanner';
import Footer from '@/components/Footer';
import WhatsAppWidget from '@/components/WhatsAppWidget';

export default function Home() {
  return (
    <div className="relative">
      <MandalaBackground />
      <Navbar />
      <main className="relative">
        <Hero />
        <About />
        <WhyChoose />
        <Testimonials />
        <Gallery />
        <BookSection />
        <Services />
        <ContactForm />
        <CTABanner />
      </main>
      <Footer />
      <WhatsAppWidget />
    </div>
  );
}