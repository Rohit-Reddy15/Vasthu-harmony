/**
 * Sacred-symbol SVG icons that "draw themselves" on hover via
 * stroke-dasharray / stroke-dashoffset (pathLength normalised to 1).
 * Place inside a `.draw-host` element (e.g. the card) to trigger on
 * card hover, or hover the icon itself.
 */
const GOLD = '#B8860B';

export default function SacredIcon({ name, className = '' }) {
  const common = {
    fill: 'none',
    stroke: GOLD,
    strokeWidth: 1.2,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
  };
  const P = (key, d, delay = 0) => (
    <path key={key} className="draw-path" pathLength={1} d={d} style={{ transitionDelay: `${delay}ms` }} {...common} />
  );

  const icons = {
    star: (
      <svg viewBox="0 0 48 48" className={`draw-host ${className}`}>
        {P('o', 'M24 4 L29 17 L43 18 L32 27 L36 41 L24 33 L12 41 L16 27 L5 18 L19 17 Z')}
        {P('c', 'M24 20 m-3 0 a3 3 0 1 0 6 0 a3 3 0 1 0 -6 0', 250)}
      </svg>
    ),
    lotus: (
      <svg viewBox="0 0 48 48" className={`draw-host ${className}`}>
        {P('m', 'M24 40 m-18 0 a18 6 0 1 0 36 0', 0)}
        {P('p1', 'M24 40 Q16 28 24 12', 120)}
        {P('p2', 'M24 40 Q32 28 24 12', 240)}
        {P('p3', 'M24 40 Q12 34 10 24', 100)}
        {P('p4', 'M24 40 Q36 34 38 24', 220)}
        {P('p5', 'M24 40 Q24 30 24 18', 180)}
      </svg>
    ),
    infinity: (
      <svg viewBox="0 0 48 48" className={`draw-host ${className}`}>
        {P('i', 'M14 24 C14 16 22 16 24 24 C26 32 34 32 34 24 C34 16 26 16 24 24 C22 32 14 32 14 24 Z')}
      </svg>
    ),
    moon: (
      <svg viewBox="0 0 48 48" className={`draw-host ${className}`}>
        {P('c1', 'M34 8 A18 18 0 1 0 34 40 A14 14 0 1 1 34 8 Z')}
        {P('s1', 'M16 16 m-1.4 0 a1.4 1.4 0 1 0 2.8 0 a1.4 1.4 0 1 0 -2.8 0', 200)}
        {P('s2', 'M20 28 m-1 0 a1 1 0 1 0 2 0 a1 1 0 1 0 -2 0', 350)}
      </svg>
    ),
    compass: (
      <svg viewBox="0 0 48 48" className={`draw-host ${className}`}>
        {P('c', 'M24 8 A16 16 0 1 0 24 40 A16 16 0 1 0 24 8 Z')}
        {P('n', 'M24 14 L20 24 L24 22 L28 24 Z', 200)}
        {P('s', 'M24 34 L20 24 L24 26 L28 24 Z', 350)}
      </svg>
    ),
    sun: (
      <svg viewBox="0 0 48 48" className={`draw-host ${className}`}>
        {P('c', 'M24 24 m-6 0 a6 6 0 1 0 12 0 a6 6 0 1 0 -12 0')}
        {Array.from({ length: 12 }, (_, i) => {
          const a = (i * 30 * Math.PI) / 180;
          return (
            <line
              key={i}
              className="draw-path"
              x1={24 + 8 * Math.cos(a)}
              y1={24 + 8 * Math.sin(a)}
              x2={24 + 14 * Math.cos(a)}
              y2={24 + 14 * Math.sin(a)}
              pathLength={1}
              style={{ transitionDelay: `${100 + i * 60}ms` }}
              {...common}
            />
          );
        })}
      </svg>
    ),
  };

  return icons[name] || icons.sun;
}