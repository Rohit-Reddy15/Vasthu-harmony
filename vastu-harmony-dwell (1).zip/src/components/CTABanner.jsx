import Reveal from './Reveal';

export default function CTABanner() {
  return (
    <section className="relative bg-gradient-to-r from-[#D4AF37] to-[#B8860B] overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'radial-gradient(circle at 50% 50%, rgba(255,255,255,0.35), transparent 65%)', mixBlendMode: 'overlay' }}
        aria-hidden="true"
      />
      <Reveal className="py-16 md:py-20 px-6 text-center text-[#2D1B14] relative z-10">
        <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold leading-tight">
          Vaasthu Sandhya &mdash; We Align to Celebrate.
        </h2>
        <p className="text-[#2D1B14]/80 mt-3 max-w-xl mx-auto">
          Harmonize your space, elevate your life. Book a consultation today.
        </p>
        <a
          href="#contact"
          className="inline-block mt-7 bg-white text-[#2D1B14] px-8 py-4 rounded-full text-sm font-bold tracking-wide shadow-[0_8px_24px_rgba(45,27,20,0.18)] hover:-translate-y-0.5 transition-all"
        >
          BOOK YOUR CONSULTATION
        </a>
      </Reveal>

      {/* Wavy bottom that transitions into the footer */}
      <svg
        className="block w-full h-12 md:h-16 relative z-10"
        viewBox="0 0 1440 80"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path d="M0,80 C360,10 720,10 1080,40 C1260,55 1380,70 1440,80 L1440,80 L0,80 Z" fill="#2D1B14" />
      </svg>
    </section>
  );
}