import { Image } from '@/components/ui/image';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useRef } from 'react';
import Reveal from './Reveal';
import SectionDivider from './SectionDivider';

const BASE = 'https://base44.app/api/apps/6a68b6c8f9de3273ba7b5fbb/files/mp/public/6a68b6c8f9de3273ba7b5fbb/';

const categories = [
  {
    title: 'Divine Presence',
    files: [
      '0e32a35c4_CollageMaker_20200625_071205974.jpg',
      '1605e2066_CollageMaker_20200625_071709870.jpg',
      '89fc47e00_CollageMaker_20200625_072219788.jpg',
      'b884fea75_CollageMaker_20200625_073153946.jpg',
      '1f60544f8_CollageMaker_20200625_073638577.jpg',
      'a12500d9d_CollageMaker_20200702_052638181.jpg',
      '3e1ca724d_CollageMaker_20200704_210316271.jpg',
      'b8e67264c_IMG_20170821_124132.jpg',
      '054f178c7_Screenshot_2023-08-14-08-57-43-42_6012fa4d4ddec268fc5c7112cbb265e7.jpg',
      '7b57f37a2_WhatsAppImage2026-07-03at1141241.jpeg',
      'b61c1cfce_WhatsAppImage2026-07-03at1141253.jpeg',
      'c02cee9ed_WhatsAppImage2026-07-03at114125.jpeg',
      'bcba7ace5_WhatsAppImage2026-07-28at202948.jpeg',
    ],
  },
  {
    title: 'Gurus',
    files: [
      '6ab1c5d96_WhatsAppImage2024-01-22at223314_47b2c189.jpg',
      '8956139f6_WhatsAppImage2026-07-05at202520.jpeg',
      '23aee61d1_WhatsAppImage2026-07-05at202940.jpeg',
      '13cf0ec0c_WhatsAppImage2026-07-05at203820.jpeg',
      '50ff797ed_WhatsAppImage2026-07-05at205014.jpeg',
      'cfcd1b8fb_WhatsAppImage2026-07-05at205222.jpeg',
      '3a2024dc7_WhatsAppImage2026-07-05at205253.jpeg',
    ],
  },
  {
    title: 'Annaprasadam',
    files: [
      'ff274d31f_IMG_20210523_104126.jpg',
      '9f8a54c08_IMG_20210523_104145.jpg',
      '692469461_IMG_20210524_124111.jpg',
      'bccaf4516_SAVE_20210524_140024.jpg',
      '77cbab039_SAVE_20210524_140100.jpg',
      '96e04c690_SAVE_20210524_141913.jpg',
      '321c63063_SAVE_20210524_142020.jpg',
      '9b61ad012_SAVE_20210524_142050.jpg',
      '9fe4f9e77_SAVE_20210524_152241.jpg',
      'b26f10bcc_WhatsAppImage2024-01-12at201000_28f8d5d2.jpg',
      '02d7f213f_WhatsAppImage2026-07-05at202719.jpg',
      '026808f6d_WhatsAppImage2026-07-05at202743.jpg',
      'edc4d0d10_WhatsAppImage2026-07-05at202913.jpg',
      '36a80639d_WhatsAppImage2026-07-05at203109.jpg',
      '7c8382622_WhatsAppImage2026-07-05at203120.jpg',
      'b769c7325_WhatsAppImage2026-07-05at203154.jpg',
      '6825308b6_WhatsAppImage2026-07-05at210746.jpg',
      '2d02755bf_WhatsAppImage2026-07-05at210836.jpg',
      'e9fb925dc_WhatsAppImage2026-07-05at210850.jpg',
      'b09679e0d_WhatsAppImage2026-07-05at211012.jpg',
      '3843cde5f_WhatsAppImage2026-07-05at211634.jpg',
      '1de13d457_WhatsAppImage2026-07-05at211659.jpg',
      'f683273fc_WhatsAppImage2026-07-05at211806.jpg',
      '0b7c23076_WhatsAppImage2026-07-05at211845.jpg',
    ],
  },
  {
    title: 'Classes',
    files: [
      '83ea927ea_1Kuberabatch.jpg',
      'd3a4d1f2d_2IshaBatch.jpg',
      '959941dd2_2IshaBatch_2.jpg',
      'c23251153_3IndhraBatch.jpg',
      'b330be951_4AgneeBatch.jpg',
      'f96ed9a00_5YamadharmaBatch.jpg',
      '4baa4279e_6NirutaBatch.jpg',
      '35331b10c_6NirutaBatch_2.jpg',
      '8c1826a39_7VarunaBatch.jpg',
      'b96d2a02c_7VarunaBatch_2.jpg',
      '717a92d6b_7VarunaBatch_3.jpg',
      '5612e8bb6_AshwiniBatch.jpg',
      '992f7b84b_LOAClass.jpg',
    ],
  },
  {
    title: 'Old Temples',
    files: [
      '81c61d72c_1KumaraLingamKolanupaka.jpg',
      '712e2a043_2AdiJambavaMatamKolanupaka.jpg',
      '2e4e184f7_3AryaVysyaMatamKolanupaka.jpg',
    ],
  },
  {
    title: 'Political Engagements',
    files: [
      'a171bb621_WhatsAppImage2026-07-05at203934.jpeg',
      'ecaaa794f_WhatsAppImage2026-07-05at204031.jpeg',
      'a99440d53_WhatsAppImage2026-07-05at204050.jpeg',
      'de6458755_WhatsAppImage2026-07-05at204126.jpeg',
      '4ba985325_WhatsAppImage2026-07-05at204148.jpeg',
      '7a9cce525_WhatsAppImage2026-07-05at205802.jpeg',
      '1091fb19d_WhatsAppImage2026-07-05at212045.jpeg',
    ],
  },
];

function GalleryRow({ title, images }) {
  const scroller = useRef(null);

  const scrollBy = (dir) => {
    if (!scroller.current) return;
    scroller.current.scrollBy({ left: dir * 320, behavior: 'smooth' });
  };

  return (
    <div className="mb-12 last:mb-0">
      <div className="flex items-center justify-between mb-4 max-w-6xl mx-auto">
        <div className="flex items-center gap-3">
          <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
          <h3 className="font-display text-xl md:text-2xl font-bold text-[#2D1B14]">{title}</h3>
          <span className="text-xs text-[#5A4A3E]/55 ml-1">{images.length} photos</span>
        </div>
        <div className="hidden sm:flex gap-2 relative z-[60]">
          <button
            onClick={() => scrollBy(-1)}
            aria-label={`Scroll ${title} left`}
            className="w-9 h-9 rounded-full border border-[#D4AF37]/40 bg-white/60 backdrop-blur-md flex items-center justify-center text-[#B8860B] hover:bg-[#D4AF37]/15 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => scrollBy(1)}
            aria-label={`Scroll ${title} right`}
            className="w-9 h-9 rounded-full border border-[#D4AF37]/40 bg-white/60 backdrop-blur-md flex items-center justify-center text-[#B8860B] hover:bg-[#D4AF37]/15 transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div
        ref={scroller}
        className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory scroll-smooth [scrollbar-width:thin]"
        style={{ scrollbarColor: 'rgba(212,175,55,0.5) transparent' }}
      >
        {images.map((src, i) => (
          <div
            key={i}
            className="relative flex-shrink-0 w-64 md:w-80 snap-start rounded-2xl overflow-hidden border border-[#D4AF37]/25 shadow-[0_8px_28px_rgba(45,27,20,0.12)] group select-none"
          >
            <Image
              src={src}
              alt={`${title} ${i + 1}`}
              fittingType="fill"
              loading="lazy"
              draggable={false}
              className="w-full h-60 md:h-72 object-cover pointer-events-none transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
            <span className="absolute bottom-3 left-3 text-[0.65rem] font-semibold tracking-wider text-white/90 uppercase opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              {title}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Gallery() {
  return (
    <section id="gallery" className="relative py-20 md:py-28 px-6">
      <Reveal className="text-center mb-14 max-w-2xl mx-auto">
        <p className="text-xs font-semibold tracking-[0.25em] text-[#B8860B] uppercase">Visual Legacy</p>
        <h2 className="font-display text-4xl md:text-5xl font-bold text-[#2D1B14] mt-3 leading-tight">
          Our Gallery
        </h2>
        <SectionDivider className="mt-4" />
        <p className="text-[#5A4A3E] mt-5">
          A glimpse into Guruji&rsquo;s journey &mdash; divine blessings, revered gurus, and moments of service.
        </p>
      </Reveal>

      <Reveal className="max-w-6xl mx-auto">
        {categories.map((c) => (
          <GalleryRow key={c.title} title={c.title} images={c.files.map((f) => BASE + f)} />
        ))}
      </Reveal>
    </section>
  );
}