import { BookOpen, ArrowRight, Sparkles } from 'lucide-react';
import Reveal from './Reveal';
import SectionDivider from './SectionDivider';

const BOOK_URL = 'https://go.fliplink.me/view/A2C4B900-6AF2-4AC0-9DFE-FE7854A9DAF5';

const highlights = [
  'Life-threatening Vaasthu Doshas explained simply',
  'Scientific remedies without breaking a single wall',
  'Real case studies from 26+ years of practice',
  'A blend of Vedic wisdom and modern floor analysis',
];

export default function BookSection() {
  return (
    <section id="book" className="relative py-20 md:py-28 px-6">
      <Reveal className="text-center max-w-2xl mx-auto mb-12">
        <p className="text-xs font-semibold tracking-[0.25em] text-[#B8860B] uppercase">From Our Guruji</p>
        <h2 className="font-display text-4xl md:text-5xl font-bold text-[#2D1B14] mt-3 leading-tight">
          The{' '}
          <span className="bg-gradient-to-r from-[#D4AF37] to-[#B8860B] bg-clip-text text-transparent">
            Vaasthu Sandhya
          </span>{' '}
          Book
        </h2>
        <SectionDivider className="mt-4" />
        <p className="text-[#5A4A3E] mt-5">
          Explore Guruji&rsquo;s authored work &mdash; a practical guide to understanding and correcting Vaasthu
          doshas with scientific, non-demolition remedies.
        </p>
      </Reveal>

      <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-10 lg:gap-14 items-center">
        {/* Left — ornamental book graphic */}
        <Reveal>
          <div className="relative mx-auto max-w-sm aspect-[4/5]">
            <div className="absolute -inset-6 bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.22),transparent_70%)] blur-2xl pointer-events-none" />
            <div className="absolute -inset-2 border border-[#D4AF37]/45 rounded-[1.75rem] pointer-events-none" />
            <div className="absolute -inset-4 border border-[#D4AF37]/25 rounded-[2rem] pointer-events-none" />
            <div className="relative w-full h-full rounded-[1.5rem] overflow-hidden border border-[#D4AF37]/60 shadow-[0_24px_80px_rgba(45,27,20,0.28)] bg-gradient-to-br from-[#F5EFE0] to-[#E8DCC2] flex flex-col items-center justify-center p-10 text-center">
              <BookOpen className="w-20 h-20 text-[#B8860B] mb-6" strokeWidth={1.1} />
              <h3 className="font-display text-2xl font-bold text-[#2D1B14] leading-tight">
                Vaasthu Sandhya
              </h3>
              <p className="text-[#5A4A3E] text-sm mt-3 leading-relaxed italic max-w-[16rem]">
                Life-threatening Vaasthu Doshas That Can Transform Your Life
              </p>
              <div className="mt-6 flex items-center gap-2 text-[0.65rem] font-semibold tracking-[0.2em] text-[#B8860B] uppercase">
                <Sparkles className="w-3.5 h-3.5" /> By Sri D. Murali Krishna Guruji
              </div>
            </div>
          </div>
        </Reveal>

        {/* Right — content + CTA */}
        <Reveal delay={150}>
          <div>
            <h3 className="font-display text-2xl md:text-3xl font-bold text-[#8B0000] mb-5">
              Read the Book Online
            </h3>
            <p className="text-[#5A4A3E] leading-[1.8] mb-6">
              Guruji&rsquo;s acclaimed book distills decades of experience into an accessible, actionable guide.
              Flip through the pages digitally and learn how small, scientific corrections can transform the
              energy of any space.
            </p>

            <a
              href={BOOK_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#2D1B14] px-7 py-3.5 rounded-full text-sm font-bold tracking-wide shadow-[0_8px_24px_rgba(212,175,55,0.3)] hover:shadow-[0_10px_30px_rgba(212,175,55,0.45)] transition-shadow"
            >
              <BookOpen className="w-4 h-4" strokeWidth={2.1} /> Open the Book
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}