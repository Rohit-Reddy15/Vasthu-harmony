export default function MandalaBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden" aria-hidden="true">
      {/* Soft pearlescent glows */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 18% 16%, rgba(212,175,55,0.16), transparent 50%), radial-gradient(circle at 84% 80%, rgba(150,110,200,0.14), transparent 50%)',
          mixBlendMode: 'multiply',
        }}
      />

      {/* Rotating gold mandala, etched into the background */}
      <svg
        className="mandala-rotate absolute left-1/2 top-1/2"
        style={{ opacity: 0.07, mixBlendMode: 'multiply' }}
        width="1100"
        height="1100"
        viewBox="0 0 900 900"
        fill="none"
      >
        <g stroke="#B8860B" strokeWidth="0.5">
          {[120, 220, 310, 380, 420].map((r, i) => (
            <rect key={i} x={450 - r} y={450 - r} width={r * 2} height={r * 2} fill="none" />
          ))}
          <line x1="30" y1="30" x2="870" y2="870" strokeWidth="0.5" />
          <line x1="870" y1="30" x2="30" y2="870" strokeWidth="0.5" />
          <line x1="450" y1="30" x2="450" y2="870" strokeWidth="0.5" />
          <line x1="30" y1="450" x2="870" y2="450" strokeWidth="0.5" />
          <circle cx="450" cy="450" r="70" strokeWidth="1" />
          <circle cx="450" cy="450" r="45" strokeWidth="0.8" />
          <circle cx="450" cy="450" r="20" strokeWidth="0.8" />
          {[0, 30, 60, 90, 120, 150].map((deg) => (
            <line
              key={deg}
              x1="450"
              y1="450"
              x2={450 + 420 * Math.cos((deg * Math.PI) / 180)}
              y2={450 + 420 * Math.sin((deg * Math.PI) / 180)}
              strokeWidth="0.3"
            />
          ))}
        </g>
      </svg>
    </div>
  );
}