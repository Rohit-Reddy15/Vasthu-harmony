export default function SectionDivider({ className = '', center = true }) {
  return (
    <div className={`flex items-center gap-2 ${center ? 'justify-center' : ''} ${className}`}>
      <span className="block w-9 h-[3px] rounded-full bg-[#8B0000]" />
      <span className="block w-9 h-[3px] rounded-full bg-[#D4AF37]" />
      <span className="block w-9 h-[3px] rounded-full bg-[#FF9933]" />
    </div>
  );
}