import { useState } from 'react';
import { Phone, Mail, MapPin, Clock, MessageCircle, Loader2, Check, ChevronDown } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import Reveal from './Reveal';
import SectionDivider from './SectionDivider';

const WHATSAPP_BASE = 'https://wa.me/918152937456';
const WHATSAPP = `${WHATSAPP_BASE}?text=${encodeURIComponent('Hi Sir, I am interested in getting a Birth Chart (Kundali) reading and Vaasthu consultation. Please share details about the fee structure and appointment timings.')}`;
const PHONEDisplay = '+91 81529 37456';
const EMAIL = 'vaasthusandhya@gmail.com';
const LOCATION = 'Hyderabad, Telangana, India';
const HOURS = ['Sun \u2013 Sat: 9:00 AM \u2013 6:00 PM', 'With prior appointment only'];

const serviceTypes = [
  'Gurudakshina for Better Future (\u20b93,111)',
  'Gurudakshina for Better Home (\u20b910,116)',
  'Gurudakshina for Better Business-I (\u20b925,116)',
  'Gurudakshina for Better Business-II (\u20b950,001)',
  'Gurudakshina for Better Building (\u20b910 per Sq.Ft)',
];

const infoCards = [
  { icon: Phone, label: 'Phone', value: PHONEDisplay, href: 'tel:+918152937456' },
  { icon: Mail, label: 'Email', value: EMAIL, href: `mailto:${EMAIL}` },
  { icon: MapPin, label: 'Location', value: LOCATION },
];

export default function ContactForm() {
  const [form, setForm] = useState({ name: '', phone: '', service_type: '', preferred_date: '', property_location: '', message: '' });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.phone) {
      setError('Please enter your name and phone number.');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      await base44.entities.ConsultationRequest.create({
        name: form.name,
        phone: form.phone,
        service_type: form.service_type,
        preferred_date: form.preferred_date,
        property_location: form.property_location,
        message: form.message,
      });

      const lines = [
        `*Vaasthu Sandhya — New Enquiry*`,
        `Name: ${form.name}`,
        `Phone: ${form.phone}`,
        form.service_type && `Service Type: ${form.service_type}`,
        form.preferred_date && `Preferred Date: ${form.preferred_date}`,
        form.property_location && `Property Location: ${form.property_location}`,
        form.message && `Message: ${form.message}`,
      ].filter(Boolean);
      const waLink = `${WHATSAPP_BASE}?text=${encodeURIComponent(lines.join('\n'))}`;
      window.open(waLink, '_blank', 'noopener,noreferrer');
      setSuccess(true);
    } catch {
      setError('Something went wrong. Please try again or message us on WhatsApp.');
    } finally {
      setSubmitting(false);
    }
  };

  const inputClass = 'w-full bg-white/70 backdrop-blur-md border border-[#D4AF37]/30 rounded-lg px-4 py-3 text-sm text-[#2D1B14] placeholder:text-[#5A4A3E]/45 focus:border-[#D4AF37] focus:outline-none transition-colors';
  const labelClass = 'text-[0.7rem] font-semibold tracking-wider text-[#B8860B] uppercase mb-1.5 block';

  return (
    <section id="contact" className="relative py-20 md:py-28 px-6">
      {/* Header */}
      <Reveal className="text-center max-w-2xl mx-auto mb-12">
        <p className="text-xs font-semibold tracking-[0.25em] text-[#B8860B] uppercase">Get In Touch</p>
        <h2 className="font-display text-4xl md:text-5xl font-bold text-[#2D1B14] mt-3 leading-tight">
          Start Your Consultation Today
        </h2>
        <SectionDivider className="mt-4" />
        <p className="text-[#5A4A3E] mt-5">
          Ready to harmonize your space? Reach out &mdash; we&rsquo;d love to hear about your property.
        </p>
      </Reveal>

      <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-8 lg:gap-12 items-start">
        {/* Left — chat + info */}
        <Reveal>
          <div className="space-y-4">
            <div className="rounded-2xl bg-gradient-to-br from-[#FFE9A0]/80 to-[#F0D9F5]/70 backdrop-blur-md border border-[#D4AF37]/40 p-7 text-[#2D1B14] shadow-[0_12px_44px_rgba(45,27,20,0.1)]">
              <h3 className="font-display text-2xl font-bold flex items-center gap-2 text-[#8B0000]">
                <MessageCircle className="w-6 h-6" /> Chat with Us on WhatsApp
              </h3>
              <p className="text-[#5A4A3E] text-sm mt-2 leading-relaxed">
                The fastest way to reach us. Send a message and we&rsquo;ll reply within minutes.
              </p>
              <a
                href={WHATSAPP}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 mt-4 bg-white/80 hover:bg-white border border-[#25D366]/50 px-5 py-3 rounded-full text-sm font-semibold text-[#1a8a3f] transition-colors"
              >
                <MessageCircle className="w-4 h-4" /> {PHONEDisplay}
              </a>
            </div>

            {infoCards.map((c) => {
              const Inner = (
                <>
                  <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#FFE9A0] to-[#D4AF37] flex items-center justify-center flex-shrink-0">
                    <c.icon className="w-5 h-5 text-[#8B0000]" strokeWidth={1.7} />
                  </div>
                  <div>
                    <p className="text-[0.7rem] font-semibold tracking-wider text-[#5A4A3E] uppercase">{c.label}</p>
                    <p className="text-[#2D1B14] text-sm font-medium mt-0.5">{c.value}</p>
                  </div>
                </>
              );
              return c.href ? (
                <a key={c.label} href={c.href} className="flex items-center gap-4 bg-white/70 backdrop-blur-md border border-[#D4AF37]/25 rounded-xl p-4 transition-all duration-300 hover:scale-[1.02] hover:border-[#D4AF37]/50 hover:shadow-[0_8px_24px_rgba(212,175,55,0.18)]">
                  {Inner}
                </a>
              ) : (
                <div key={c.label} className="flex items-center gap-4 bg-white/70 backdrop-blur-md border border-[#D4AF37]/25 rounded-xl p-4">
                  {Inner}
                </div>
              );
            })}

            <div className="flex items-start gap-4 bg-white/70 backdrop-blur-md border border-[#D4AF37]/25 rounded-xl p-4">
              <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#FFE9A0] to-[#D4AF37] flex items-center justify-center flex-shrink-0">
                <Clock className="w-5 h-5 text-[#8B0000]" strokeWidth={1.7} />
              </div>
              <div>
                <p className="text-[0.7rem] font-semibold tracking-wider text-[#5A4A3E] uppercase">Working Hours</p>
                {HOURS.map((h) => (
                  <p key={h} className="text-[#2D1B14] text-sm font-medium mt-0.5">{h}</p>
                ))}
              </div>
            </div>
          </div>
        </Reveal>

        {/* Right — form */}
        <Reveal delay={120}>
          <div className="bg-white/75 backdrop-blur-md border border-[#D4AF37]/30 rounded-2xl shadow-[0_12px_50px_rgba(45,27,20,0.1)] p-7 md:p-9">
            {success ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-[#25D366]/15 flex items-center justify-center mx-auto">
                  <Check className="w-8 h-8 text-[#1a8a3f]" />
                </div>
                <h3 className="font-display text-2xl font-bold text-[#8B0000] mt-5">Enquiry Received</h3>
                <p className="text-[#5A4A3E] mt-3 max-w-sm mx-auto text-sm">
                  Thank you for reaching out. Our Vaasthu expert will contact you on WhatsApp shortly.
                </p>
                <a
                  href={WHATSAPP}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 mt-6 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#2D1B14] px-6 py-3 rounded-full text-sm font-semibold"
                >
                  <MessageCircle className="w-4 h-4" /> Chat Now
                </a>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <h3 className="font-display text-2xl font-bold text-[#8B0000]">Send Us an Enquiry</h3>
                  <p className="text-sm text-[#5A4A3E] mt-1">Fill this form and we&rsquo;ll contact you on WhatsApp instantly</p>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className={labelClass}>Your Name *</label>
                    <input type="text" name="name" value={form.name} onChange={handleChange} required placeholder="e.g. Rahul Sharma" className={inputClass} />
                  </div>
                  <div>
                    <label className={labelClass}>Phone Number *</label>
                    <input type="tel" name="phone" value={form.phone} onChange={handleChange} required placeholder="+91 98765 43210" className={inputClass} />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className={labelClass}>Service Type</label>
                    <div className="relative">
                      <select name="service_type" value={form.service_type} onChange={handleChange} className={`${inputClass} appearance-none pr-10`}>
                        <option value="">Select service type...</option>
                        {serviceTypes.map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#B8860B] pointer-events-none" />
                    </div>
                  </div>
                  <div>
                    <label className={labelClass}>Preferred Date</label>
                    <input type="date" name="preferred_date" value={form.preferred_date} onChange={handleChange} className={inputClass} />
                  </div>
                </div>

                <div>
                  <label className={labelClass}>Property Location</label>
                  <input type="text" name="property_location" value={form.property_location} onChange={handleChange} placeholder="e.g. Kukatpally, Hyderabad, Telangana" className={inputClass} />
                </div>

                <div>
                  <label className={labelClass}>Message</label>
                  <textarea name="message" value={form.message} onChange={handleChange} rows={4} placeholder="Tell us about your property — type, concerns, timeline..." className={`${inputClass} resize-none`} />
                </div>

                {error && <p className="text-sm text-[#8B0000]">{error}</p>}

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#2D1B14] py-4 rounded-lg text-sm font-bold tracking-wide shadow-[0_8px_24px_rgba(212,175,55,0.3)] hover:shadow-[0_10px_30px_rgba(212,175,55,0.45)] transition-shadow disabled:opacity-60 flex items-center justify-center gap-2"
                >
                  {submitting ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> Submitting...</>
                  ) : (
                    <>SUBMIT ENQUIRY</>
                  )}
                </button>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}