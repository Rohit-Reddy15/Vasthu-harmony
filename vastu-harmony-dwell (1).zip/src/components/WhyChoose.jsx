import Reveal from './Reveal';
import SectionDivider from './SectionDivider';
import SacredIcon from './AnimatedIcons';

const cards = [
  { icon: 'star', title: 'Extensive Experience', body: 'Over 26 years of proven Vaasthu expertise across thousands of residential and commercial spaces.' },
  { icon: 'lotus', title: 'Scientific Remedies Approach', body: 'Energy-balancing remedies that correct doshas with scientific solutions.' },
  { icon: 'infinity', title: 'Vedic & Modern Fusion', body: 'Traditional Vaasthu Shastra combined with precise modern floor plan analysis.' },
  { icon: 'moon', title: 'Extensive Experience', body: 'Over 19 years of proven Astrology expertise across thousands of Kundli analysis.' },
  { icon: 'compass', title: 'Global Online Reach', body: 'Virtual consultations via floor plans, serving clients anywhere in the world.' },
  { icon: 'sun', title: 'Proven Harmony', body: 'Thousands of harmonized spaces with lasting, measurable positive results.' },
];

export default function WhyChoose() {
  return (
    <section className="relative py-20 md:py-24 px-6">
      <Reveal className="text-center max-w-2xl mx-auto mb-14">
        <p className="text-xs font-semibold tracking-[0.25em] text-[#B8860B] uppercase">Our Promise</p>
        <h2 className="font-display text-4xl md:text-5xl font-bold text-[#2D1B14] mt-3 leading-tight">
          Why Choose{' '}
          <span className="bg-gradient-to-r from-[#D4AF37] to-[#B8860B] bg-clip-text text-transparent">
            Vaasthu Sandhya?
          </span>
        </h2>
        <SectionDivider className="mt-4" />
      </Reveal>

      <div className="max-w-6xl mx-auto grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {cards.map((c, i) => (
          <Reveal key={c.title} delay={i * 80}>
            <div className="draw-host bg-white/70 backdrop-blur-md border border-[#D4AF37]/25 rounded-2xl p-7 shadow-[0_4px_24px_rgba(45,27,20,0.06)] transition-all duration-300 hover:scale-[1.02] hover:border-[#D4AF37]/50 hover:shadow-[0_12px_40px_rgba(212,175,55,0.18)] h-full">
              <div className="w-16 h-16 mb-5">
                <SacredIcon name={c.icon} className="w-full h-full" />
              </div>
              <h3 className="font-display text-xl font-bold text-[#2D1B14] mb-2">{c.title}</h3>
              <p className="text-[#5A4A3E] text-sm leading-relaxed">{c.body}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}