import { Phone, Instagram, Youtube, MessageCircle, ArrowRight, BookOpen } from 'lucide-react';
import Logo from './Logo';

const WHATSAPP = `https://wa.me/918152937456?text=${encodeURIComponent('Hi Sir, I am interested in getting a Birth Chart (Kundali) reading and Vaasthu consultation. Please share details about the fee structure and appointment timings.')}`;

const quickLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Our Services', href: '#services' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Contact Us', href: '#contact' },
];

export default function Footer() {
  return (
    <footer className="bg-[#2D1B14] text-white relative">
      <div className="max-w-6xl mx-auto px-6 py-14 grid md:grid-cols-3 gap-10">
        {/* Brand */}
        <div>
          <div className="flex items-center gap-3 mb-4">
            <Logo size={44} />
            <div className="leading-tight">
              <div className="flex items-baseline gap-1.5">
                <span className="font-display text-lg font-bold text-white">Vaasthu</span>
                <span className="font-display text-lg font-bold italic text-[#FACC15]">Sandhya</span>
              </div>
              <p className="text-[0.6rem] tracking-[0.15em] text-[#F97316] uppercase">Consultancy</p>
            </div>
          </div>
          <p className="text-sm text-white/70 leading-relaxed max-w-xs">
            Harmonizing living and work spaces across India and worldwide for over a decade. Your harmony is
            our expertise.
          </p>
          <p className="font-display italic text-[#FACC15] mt-4 text-sm">
            &ldquo;Harmonize. Prosper. Celebrate.&rdquo;
          </p>
        </div>

        {/* Quick links */}
        <div>
          <h4 className="text-sm font-bold tracking-[0.2em] text-[#F97316] uppercase mb-4">Quick Links</h4>
          <ul className="space-y-2.5">
            {quickLinks.map((l) => (
              <li key={l.href}>
                <a href={l.href} className="inline-flex items-center gap-2 text-sm text-white/80 hover:text-[#FACC15] transition-colors">
                  <ArrowRight className="w-3.5 h-3.5 text-[#F97316]" /> {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="text-sm font-bold tracking-[0.2em] text-[#F97316] uppercase mb-4">Contact</h4>
          <p className="text-[0.65rem] font-semibold tracking-wider text-white/50 uppercase">Phone / WhatsApp</p>
          <a href={WHATSAPP} target="_blank" rel="noopener noreferrer" className="block text-white text-sm hover:text-[#FACC15] transition-colors mb-3">
            +91 81529 37456
          </a>
          <p className="text-[0.65rem] font-semibold tracking-wider text-white/50 uppercase">Location</p>
          <p className="text-white text-sm mb-5">Hyderabad, Telangana, India</p>

          <div className="flex flex-col sm:flex-row gap-3">
            <a
              href="https://www.instagram.com/muralikrishna.dintakurthi"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-[#F97316] to-[#E67E22] text-white px-4 py-2.5 rounded-full text-xs font-semibold hover:opacity-90 transition-opacity"
            >
              <Instagram className="w-4 h-4" /> Follow on Instagram
            </a>
            <a
              href="https://youtube.com/@vaasthusandhya"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-[#FF0000] to-[#CC0000] text-white px-4 py-2.5 rounded-full text-xs font-semibold hover:opacity-90 transition-opacity"
            >
              <Youtube className="w-4 h-4" /> Watch on YouTube
            </a>
            <a
              href={WHATSAPP}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-[#25D366] text-white px-4 py-2.5 rounded-full text-xs font-semibold hover:bg-[#1faa55] transition-colors"
            >
              <MessageCircle className="w-4 h-4" /> WhatsApp Us
            </a>
            <a
              href="https://go.fliplink.me/view/A2C4B900-6AF2-4AC0-9DFE-FE7854A9DAF5"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#2D1B14] px-4 py-2.5 rounded-full text-xs font-semibold hover:opacity-90 transition-opacity"
            >
              <BookOpen className="w-4 h-4" /> Vaasthu Sandhya Book
            </a>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs text-white/50">&copy; {new Date().getFullYear()} Vaasthu Sandhya Consultancy. All rights reserved.</p>
          <p className="text-xs text-white/50">Crafted with <span className="text-[#F97316]">&hearts;</span> for harmonious living.</p>
        </div>
      </div>
    </footer>
  );
}