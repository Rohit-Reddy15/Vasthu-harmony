import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';

const faqs = [
  {
    q: 'Is demolition required for Vaasthu corrections?',
    a: 'Not at all. Our specialty is scientific remedies. We use strategic energy-balancing tools — copper pyramids, crystal placements, color therapy, metal strips, and directional mirrors — to correct defects with scientific solutions. Your home stays intact while its energy realigns.',
  },
  {
    q: 'How does an online / virtual Vaasthu consultation work?',
    a: 'You share your floor plan (CAD, PDF, or hand-drawn sketch) along with the exact directional orientation of your property. We conduct a comprehensive analysis of room placement, entrances, kitchen direction, and energy zones, then deliver a detailed remedy report with precise placement instructions — all remotely, with the same depth as an on-site visit.',
  },
  {
    q: 'How long does it take to see results after remedies?',
    a: 'Most clients begin noticing positive shifts within 3 to 6 weeks of implementing the remedies. The timeline depends on the severity of existing doshas and how precisely the remedies are placed. We provide ongoing guidance to ensure the energy corrections take full effect.',
  },
  {
    q: 'Can Vaasthu be applied to apartments and flats?',
    a: 'Absolutely. Vaasthu principles apply equally to apartments. In fact, many flats have directional misalignments that can be corrected with non-invasive remedies. We assess the main entrance direction, kitchen placement, bedroom zones, and common areas to harmonize the energy flow within multi-unit dwellings.',
  },
  {
    q: 'Do you consult for commercial properties and offices?',
    a: 'Yes. Commercial Vaasthu is one of our core specialties. We audit office layouts, cabin positions, cash counter placement, and entrance directions to optimize productivity, staff harmony, and financial growth. We also serve retail outlets, warehouses, and industrial sites.',
  },
  {
    q: 'What information do I need to provide for a consultation?',
    a: 'For the most accurate analysis, we need: your floor plan (if available), the exact facing direction of the main entrance (use a compass app), the year the property was built or purchased, and any specific concerns you\u2019re experiencing (health, finances, relationships, etc.). The more detail, the more precise the remedies.',
  },
];

function FAQItem({ faq, isOpen, onToggle }) {
  return (
    <div className="border-b border-[#D4AF37]/30">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between gap-6 py-7 text-left group"
      >
        <span className="font-display text-lg md:text-xl text-[#2D1B14] group-hover:text-[#B8860B] transition-colors font-medium">
          {faq.q}
        </span>
        <span className="flex-shrink-0 w-8 h-8 rounded-full border border-[#B8860B]/40 flex items-center justify-center text-[#B8860B]">
          {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
        </span>
      </button>
      <div
        className="overflow-hidden transition-all duration-500 ease-in-out"
        style={{ maxHeight: isOpen ? '300px' : '0px', opacity: isOpen ? 1 : 0 }}
      >
        <p className="pb-7 text-[0.95rem] text-[#5A4A3E] leading-relaxed pr-12">
          {faq.a}
        </p>
      </div>
    </div>
  );
}

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <section id="faq" className="relative py-24 md:py-32 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-14">
          <span className="text-xs uppercase tracking-[0.3em] text-[#B8860B] font-medium">
            Clarity & Guidance
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-[#2D1B14] mt-4 font-light leading-tight">
            Frequently Asked Questions
          </h2>
          <div className="w-16 h-px bg-[#B8860B]/40 mx-auto mt-6" />
        </div>

        <div>
          {faqs.map((faq, i) => (
            <FAQItem
              key={i}
              faq={faq}
              isOpen={openIndex === i}
              onToggle={() => setOpenIndex(openIndex === i ? -1 : i)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}