import { ArrowRight } from 'lucide-react';
import { Image } from '@/components/ui/image';
import Reveal from './Reveal';

const services = [
  {
    title: 'Gurudakshina for Better Future',
    price: '₹3,111 /-',
    desc: '<ul class="list-disc pl-5 space-y-1"><li>Astrology</li><li>Numerology</li><li>Palmistry</li></ul>',
    img: 'https://media.base44.com/images/public/6a68b6c8f9de3273ba7b5fbb/40126eb3e_generated_621e6527.png',
  },
  {
    title: 'Gurudakshina for Better Home',
    price: '₹10,116 /-',
    desc: '<ul class="list-disc pl-5 space-y-1"><li>Vaasthu one time visit for Home / Flat / Plot etc. (Only one unit)</li><li>Conveyance charges extra for outstation visits</li></ul>',
    img: 'https://media.base44.com/images/public/6a68b6c8f9de3273ba7b5fbb/89db87616_generated_5cc21dfe.png',
  },
  {
    title: 'Gurudakshina for Better Business-I',
    price: '₹25,116 /-',
    desc: '<ul class="list-disc pl-5 space-y-1"><li>Vaasthu one time visit for Shop / Office etc. (Only one unit)</li><li>Conveyance charges extra for outstation visits</li></ul>',
    img: 'https://media.base44.com/images/public/6a68b6c8f9de3273ba7b5fbb/dc3c18be5_generated_d5522d83.png',
  },
  {
    title: 'Gurudakshina for Better Business-II',
    price: '₹50,001 /-',
    desc: '<ul class="list-disc pl-5 space-y-1"><li>Vaasthu one time visit for Factory / Big Office etc. (Only one unit)</li><li>Conveyance charges extra for outstation visits</li></ul>',
    img: 'https://media.base44.com/images/public/6a68b6c8f9de3273ba7b5fbb/dc3c18be5_generated_d5522d83.png',
  },
  {
    title: 'Gurudakshina for Better Building',
    price: '₹10 /- per Sq.Ft',
    desc: '<ul class="list-disc pl-5 space-y-1"><li>Vaasthu unlimited visits for Apartment / Commercial Complex etc.</li><li>Minimum 10,000 Sq.Ft</li><li>Conveyance charges extra for outstation visits</li></ul>',
    img: 'https://media.base44.com/images/public/6a68b6c8f9de3273ba7b5fbb/89db87616_generated_5cc21dfe.png',
  },
];

export default function Services() {
  return (
    <section id="services" className="relative py-20 md:py-28 px-6 overflow-hidden">
      <div className="relative max-w-6xl mx-auto">
        {/* Header */}
        <Reveal className="text-center mb-12">
          <p className="text-sm font-medium text-[#B8860B] tracking-[0.2em] uppercase">What We Offer</p>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-2 leading-tight bg-gradient-to-r from-[#FFDA64] to-[#B8860B] bg-clip-text text-transparent">
            Our Premium Services
          </h2>
          <p className="text-[#5A4A3E] mt-5 max-w-2xl mx-auto text-base">
            Every direction matters. We offer an end-to-end Vaasthu experience &mdash; from initial audit to
            the final energy-activating remedy.
          </p>
        </Reveal>

        {/* Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-10">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={i * 100}>
              <div className="draw-host bg-white/70 backdrop-blur-md border border-[#D4AF37]/25 rounded-2xl overflow-hidden flex flex-col group shadow-[0_4px_24px_rgba(45,27,20,0.06)] transition-all duration-300 hover:scale-[1.02] hover:border-[#D4AF37]/50 hover:shadow-[0_14px_44px_rgba(212,175,55,0.2)]">
                <div className="relative h-52 overflow-hidden">
                  <Image
                    src={s.img}
                    alt={s.title}
                    fittingType="fill"
                    className="w-full h-full transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#FAF7F1] via-[#FBE9C8]/20 to-transparent mix-blend-multiply" />
                </div>
                <div className="p-6 flex flex-col flex-grow">
                  <h3 className="font-display text-lg font-bold text-[#2D1B14] leading-snug">{s.title}</h3>
                  <p className="font-display text-xl font-bold bg-gradient-to-r from-[#D4AF37] to-[#B8860B] bg-clip-text text-transparent mt-1 mb-2">
                    {s.price}
                  </p>
                  <div
                    className="text-[#5A4A3E] text-sm leading-relaxed flex-grow"
                    dangerouslySetInnerHTML={{ __html: s.desc }}
                  />
                  <a
                    href="#contact"
                    className="inline-flex items-center justify-center gap-2 mt-5 bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#2D1B14] px-5 py-3 rounded-full text-sm font-semibold shadow-[0_4px_14px_rgba(212,175,55,0.25)] hover:shadow-[0_8px_22px_rgba(212,175,55,0.4)] transition-shadow"
                  >
                    ENQUIRE NOW
                    <ArrowRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}