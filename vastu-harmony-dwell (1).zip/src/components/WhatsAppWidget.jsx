import { useState, useEffect } from 'react';
import { MessageCircle, X } from 'lucide-react';

const WHATSAPP = `https://wa.me/918152937456?text=${encodeURIComponent('Hi Sir, I am interested in getting a Birth Chart (Kundali) reading and Vaasthu consultation. Please share details about the fee structure and appointment timings.')}`;

export default function WhatsAppWidget() {
  const [showTooltip, setShowTooltip] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(true);
      setShowTooltip(true);
    }, 2500);
    const hideTimer = setTimeout(() => setShowTooltip(false), 9000);
    return () => {
      clearTimeout(timer);
      clearTimeout(hideTimer);
    };
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-end gap-3">
      {/* Tooltip bubble */}
      <div
        className={`bg-white shadow-[0_8px_30px_rgba(45,27,20,0.18)] rounded-2xl rounded-br-sm px-4 py-3 mb-1 max-w-[220px] transition-all duration-500 origin-bottom-right ${
          showTooltip ? 'opacity-100 scale-100' : 'opacity-0 scale-90 pointer-events-none'
        }`}
      >
        <div className="flex items-start justify-between gap-2">
          <p className="text-sm text-[#2D1B14] font-medium leading-snug">
            Need instant Vaasthu advice? Chat now!
          </p>
          <button
            onClick={() => setShowTooltip(false)}
            className="text-[#2D1B14]/30 hover:text-[#2D1B14]/60 flex-shrink-0"
            aria-label="Dismiss"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Pulsing button */}
      <a
        href={WHATSAPP}
        target="_blank"
        rel="noopener noreferrer"
        className="pulse-ring relative w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg hover:scale-105 transition-transform duration-300"
        aria-label="Chat on WhatsApp"
        onMouseEnter={() => setShowTooltip(true)}
      >
        <MessageCircle className="w-7 h-7 text-white" strokeWidth={1.6} />
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-[#D4AF37] rounded-full border-2 border-white" />
      </a>
    </div>
  );
}