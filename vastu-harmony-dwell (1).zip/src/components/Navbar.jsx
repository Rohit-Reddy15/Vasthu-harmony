import { useState, useEffect } from 'react';
import { Menu, X, Instagram, Youtube, CalendarCheck, BookOpen } from 'lucide-react';
import Logo from './Logo';

const WHATSAPP = 'https://wa.me/918152937456';
const BOOK_URL = 'https://go.fliplink.me/view/A2C4B900-6AF2-4AC0-9DFE-FE7854A9DAF5';

const links = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`relative sticky top-0 z-50 transition-all duration-300 bg-[#FAF7F1]/95 backdrop-blur-xl border-b border-[#D4AF37]/25 ${scrolled ? 'shadow-[0_8px_30px_rgba(45,27,20,0.06)]' : ''}`}
    >
      <nav className="max-w-7xl mx-auto px-5 lg:px-8 py-3 flex items-center justify-between gap-6">
        {/* Brand */}
        <a href="#home" className="flex items-center gap-3 flex-shrink-0">
          <Logo size={60} />
          <div className="leading-tight">
            <h1 className="font-body font-bold text-[1.5rem] text-[#8B0000] tracking-[0.02em] leading-none">
              Vaasthu
            </h1>
            <h2 className="font-body font-bold text-[1.5rem] text-[#FF9933] tracking-[0.02em] leading-none mt-1">
              Sandhya
            </h2>
          </div>
        </a>

        {/* Center links */}
        <div className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="relative text-sm font-medium text-[#3D2A1E] hover:text-[#B8860B] transition-colors tracking-wide group"
            >
              {l.label}
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#D4AF37] transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-3">
          <a
            href={BOOK_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Vaasthu Sandhya Book"
            className="w-9 h-9 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#B8860B] flex items-center justify-center hover:opacity-90 transition-opacity"
          >
            <BookOpen className="w-4 h-4 text-white" strokeWidth={2} />
          </a>
          <a
            href="https://www.instagram.com/muralikrishna.dintakurthi"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
            className="w-9 h-9 rounded-full bg-gradient-to-br from-[#F97316] to-[#FACC15] flex items-center justify-center hover:opacity-90 transition-opacity"
          >
            <Instagram className="w-4 h-4 text-white" strokeWidth={2} />
          </a>
          <a
            href="https://youtube.com/@vaasthusandhya"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="YouTube"
            className="w-9 h-9 rounded-full bg-gradient-to-br from-[#FF0000] to-[#CC0000] flex items-center justify-center hover:opacity-90 transition-opacity"
          >
            <Youtube className="w-4 h-4 text-white" strokeWidth={2} />
          </a>
          <a
            href="#contact"
            className="book-now-glow group relative hidden sm:inline-flex items-center gap-2 overflow-hidden rounded-full bg-gradient-to-r from-[#D4AF37] to-[#B8860B] px-6 py-3 text-sm font-bold tracking-wide text-[#2D1B14] hover:-translate-y-0.5 transition-transform"
            aria-label="Book your consultation now"
          >
            <span className="pointer-events-none absolute inset-0 book-now-shimmer bg-gradient-to-r from-transparent via-white/55 to-transparent" />
            <CalendarCheck className="relative w-4 h-4 transition-transform duration-300 group-hover:rotate-[8deg] group-hover:scale-110" strokeWidth={2.2} />
            <span className="relative">BOOK NOW</span>
          </a>
          <button
            className="lg:hidden text-[#2D1B14]"
            onClick={() => setOpen(!open)}
            aria-label="Toggle menu"
          >
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {open && (
        <div className="lg:hidden bg-[#FAF7F1]/95 backdrop-blur-xl border-t border-[#D4AF37]/20">
          <div className="flex flex-col px-6 py-4 gap-1">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="text-sm font-medium text-[#3D2A1E] hover:text-[#B8860B] py-2.5 transition-colors"
              >
                {l.label}
              </a>
            ))}
            <a
              href="#contact"
              onClick={() => setOpen(false)}
              className="mt-2 inline-flex items-center justify-center bg-gradient-to-r from-[#D4AF37] to-[#B8860B] text-[#2D1B14] px-5 py-3 rounded-full text-sm font-semibold"
            >
              BOOK NOW
            </a>
          </div>
        </div>
      )}
      <div className="h-px w-full bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent" />
    </header>
  );
}