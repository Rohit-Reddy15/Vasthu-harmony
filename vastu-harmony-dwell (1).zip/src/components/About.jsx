import { useRef, useEffect, useState } from 'react';
import { Compass, Star, Sparkles } from 'lucide-react';
import { Image } from '@/components/ui/image';
import Reveal from './Reveal';
import SectionDivider from './SectionDivider';
import { CompassRoseSVG } from './SacredGeometry';

const ABOUT_IMG = 'https://media.base44.com/images/public/6a68b6c8f9de3273ba7b5fbb/63c01c16c_image.png';

const expertise = [
  { icon: Compass, title: 'Vaasthu', items: 'Scientific, Pyramid, Geopathic, & Feng Shui' },
  { icon: Star, title: 'Astrology', items: 'Vedic, Parasara, Nadi, Brugu Nandi, & K.P.' },
  { icon: Sparkles, title: 'Cosmic Sciences', items: 'Law of Attraction, Numerology, & Palmistry' },
];

function Counter({ end, suffix = '', label }) {
  const ref = useRef(null);
  const [count, setCount] = useState(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          let current = 0;
          const duration = 1800;
          const stepTime = 30;
          const steps = duration / stepTime;
          const increment = end / steps;
          const timer = setInterval(() => {
            current += increment;
            if (current >= end) {
              setCount(end);
              clearInterval(timer);
            } else {
              setCount(Math.floor(current));
            }
          }, stepTime);
          observer.unobserve(ref.current);
        }
      },
      { threshold: 0.4 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [end]);

  return (
    <div ref={ref}>
      <div className="font-display text-2xl md:text-3xl font-bold text-[#B8860B] leading-none">
        {count.toLocaleString()}
        {suffix}
      </div>
      <p className="text-[0.7rem] md:text-xs font-semibold text-[#5A4A3E] tracking-wider uppercase mt-1.5">{label}</p>
    </div>
  );
}

export default function About() {
  return (
    <section id="about" className="relative py-20 md:py-28 px-6">
      <div className="text-center mb-14 max-w-2xl mx-auto">
        <p className="text-xs font-semibold tracking-[0.25em] text-[#B8860B] uppercase">Who We Are</p>
        <h2 className="font-display text-4xl md:text-5xl font-bold text-[#2D1B14] mt-3 leading-tight">
          About{' '}
          <span className="bg-gradient-to-r from-[#D4AF37] to-[#B8860B] bg-clip-text text-transparent">
            Vaasthu Sandhya
          </span>
        </h2>
        <SectionDivider className="mt-4" />
      </div>

      <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
        {/* Left — text */}
        <Reveal>
          <div>
            <h3 className="font-display text-2xl md:text-3xl font-bold text-[#8B0000] mb-5">
              Crafting Harmonious Spaces and Life's
            </h3>
            <p className="text-[#5A4A3E] leading-[1.8] mb-4">
              <span className="font-semibold text-[#2D1B14]">Vaasthu Sandhya Consultancy</span> has been harmonizing
              residential, commercial, and industrial spaces for over two and a half decades. With deep expertise in
              traditional Vaasthu Shastra and modern architectural analysis, we are one of the leading Vaasthu advisory
              practices, offering precise, practical, and scientific solutions for properties of every scale. Our
              services include Residential Vaasthu, Commercial Vaasthu, Pre-Purchase Plot Audits, and Energy-Balancing
              Remedies.
            </p>
            <p className="text-[#5A4A3E] leading-[1.8]">
              At Vaasthu Sandhya, we blend Vedic wisdom with scientific floor plan analysis and practical remediation
              to create spaces that promote prosperity, health, success, and harmony. Whether it is a small apartment
              or a large industrial complex, we are committed to delivering excellence through proven remedies, global
              online consultations, and lasting results &mdash; with scientific solutions.
            </p>

            <h4 className="font-display text-lg font-bold text-[#8B0000] mt-7 mb-2">Astrology Expertise</h4>
            <p className="text-[#5A4A3E] leading-[1.8]">
              <span className="font-semibold text-[#2D1B14]">Sri Dintakurthi Murali Krishna Guruji</span> has extensive
              knowledge of Astrology, having studied M.A. Astrology at Potti Sriramulu Telugu University. He has
              been trained in various branches of astrology, including{' '}
              <span className="font-semibold text-[#2D1B14]">Vedic, Parashara, KP, Nadi, and Brugu Nandi</span> traditions,
              under the guidance of renowned gurus. With years of research and{' '}
              <span className="font-semibold text-[#2D1B14]">thousands of Kundli analyses</span>, Guruji provides
              practical and insightful astrological guidance, combining traditional wisdom with a scientific approach
              to help people make informed life decisions.
            </p>

            <p className="text-[#5A4A3E] leading-[1.8] mt-4">
              Guruji delivered striking predictions for the{' '}
              <span className="font-semibold text-[#2D1B14]">Telangana Assembly Elections</span> and the{' '}
              <span className="font-semibold text-[#2D1B14]">Andhra Pradesh Assembly Elections</span>. He is also
              the author of <span className="font-semibold text-[#2D1B14]">Vaasthu Sandhya &mdash; Life-threatening Vaasthu Doshas That Can Transform Your Life</span>.
            </p>

            <div className="flex flex-wrap gap-8 mt-8">
              <Counter end={26} suffix="+" label="Years of Excellence" />
              <Counter end={1000} suffix="+" label="Spaces Harmonized" />
              <Counter end={100} suffix="%" label="Client Satisfaction" />
            </div>
          </div>
        </Reveal>

        {/* Right — image with compass overlay */}
        <Reveal delay={150}>
          <div className="relative">
            <div className="rounded-2xl border-2 border-[#D4AF37]/30 overflow-hidden shadow-[0_12px_44px_rgba(45,27,20,0.14)]">
              <Image
                src={ABOUT_IMG}
                alt="Vaasthu Sandhya Vaasthu consultant at his desk"
                fittingType="fill"
                className="w-full h-[340px] md:h-[460px]"
                focalPointX={0.5}
                focalPointY={0.45}
              />
            </div>
            {/* Compass rose overlay (math SVG, ethereal glow) */}
            <div className="absolute -top-6 -right-6 hidden sm:block" style={{ mixBlendMode: 'overlay' }}>
              <CompassRoseSVG size={150} opacity={0.9} />
            </div>
            <div className="absolute bottom-5 left-5 bg-white/85 backdrop-blur-md border border-[#D4AF37]/30 shadow-[0_8px_30px_rgba(45,27,20,0.12)] rounded-xl px-5 py-4 flex items-center gap-3">
              <span className="font-display text-3xl md:text-4xl font-bold text-[#B8860B] leading-none">26+</span>
              <span className="text-[0.7rem] font-semibold text-[#3D2A1E] uppercase tracking-wider leading-tight">
                Years of<br />Excellence
              </span>
            </div>
          </div>
        </Reveal>
      </div>

      {/* Meet the Guruji */}
      <Reveal className="mt-20">
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-xs font-semibold tracking-[0.25em] text-[#B8860B] uppercase">Our Guiding Light</p>
          <h3 className="font-display text-3xl md:text-4xl font-bold text-[#2D1B14] mt-3 leading-tight">
            Sri Dintakurthi Murali Krishna Guruji
          </h3>
          <SectionDivider className="mt-4" />
          <p className="text-[#5A4A3E] leading-[1.8] mt-6">
            With over 26 years of experience, Sri Dintakurthi Murali Krishna Guruji is a renowned expert
            in Vaasthu, Astrology, and Cosmic Sciences. Merging traditional wisdom with a rigorous
            scientific approach, he provides accurate remedies to bring harmony and prosperity to
            people&rsquo;s lives. Beyond consultations, Guruji is deeply committed to social service,
            temple renovations, and philanthropy through the Annaprasadam Foundation.
          </p>
        </div>

        <div className="max-w-5xl mx-auto grid sm:grid-cols-3 gap-5 mt-10">
          {expertise.map((e) => (
            <div
              key={e.title}
              className="bg-white/70 backdrop-blur-md border border-[#D4AF37]/25 rounded-2xl p-6 text-center hover:border-[#D4AF37]/55 hover:shadow-[0_10px_30px_rgba(212,175,55,0.15)] hover:-translate-y-1 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#FFE9A0] to-[#D4AF37] flex items-center justify-center mx-auto mb-4">
                <e.icon className="w-6 h-6 text-[#8B0000]" strokeWidth={1.7} />
              </div>
              <p className="text-[0.65rem] font-semibold tracking-wider text-[#B8860B] uppercase">Core Expertise</p>
              <h4 className="font-display text-xl font-bold text-[#2D1B14] mt-1">{e.title}</h4>
              <p className="text-sm text-[#5A4A3E] mt-2 leading-relaxed">{e.items}</p>
            </div>
          ))}
        </div>
      </Reveal>
    </section>
  );
}