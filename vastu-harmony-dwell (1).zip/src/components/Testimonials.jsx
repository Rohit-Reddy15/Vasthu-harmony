import { Star } from 'lucide-react';
import Reveal from './Reveal';
import SectionDivider from './SectionDivider';

const testimonials = [
  {
    letter: 'R',
    name: 'Rajesh Verma',
    label: 'Residential Vaasthu',
    text: 'After the scientific remedies, the energy in our apartment shifted completely. Within months, my business turnover doubled and family harmony returned. Truly remarkable guidance from Vaasthu Sandhya.',
  },
  {
    letter: 'A',
    name: 'Anitha Reddy',
    label: 'Commercial Vaasthu',
    text: 'The online floor plan consultation was incredibly precise. Every directional correction was explained with logic and Vedic backing. Our new clinic is thriving since the remedies were placed.',
  },
  {
    letter: 'S',
    name: 'Suresh Choudhary',
    label: 'Online Astrology Consultation',
    text: 'Being an NRI, I was skeptical about online astrology consultations. But Dintakurthi Murali Krishna\u2019s birth chart analysis was remarkably accurate, thorough, and professional. His insightful predictions and effective astrological remedies brought complete clarity and positivity to my life.',
  },
];

export default function Testimonials() {
  return (
    <section id="reviews" className="relative py-20 md:py-28 px-6">
      <Reveal className="text-center max-w-2xl mx-auto mb-12">
        <p className="text-xs font-semibold tracking-[0.25em] text-[#5A4A3E] uppercase">What Clients Say</p>
        <h2 className="font-display text-4xl md:text-5xl font-bold mt-3 leading-tight">
          <span className="text-[#4A4A4A]">Circle of </span>
          <span className="bg-gradient-to-r from-[#D4AF37] to-[#B8860B] bg-clip-text text-transparent">Trust</span>
        </h2>
        <SectionDivider className="mt-4" />
      </Reveal>

      <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-6">
        {testimonials.map((t, i) => (
          <Reveal key={t.name} delay={i * 100}>
            <div className="bg-white/70 backdrop-blur-md border border-[#D4AF37]/25 rounded-2xl p-7 shadow-[0_4px_24px_rgba(45,27,20,0.06)] transition-all duration-300 hover:scale-[1.02] hover:border-[#D4AF37]/50 hover:shadow-[0_12px_40px_rgba(212,175,55,0.18)] h-full flex flex-col">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#FFE9A0] to-[#D4AF37] flex items-center justify-center flex-shrink-0">
                  <span className="font-display text-xl font-bold text-[#8B0000]">{t.letter}</span>
                </div>
                <div>
                  <p className="font-bold text-[#2D1B14] text-base">{t.name}</p>
                  <p className="text-sm text-[#5A4A3E]">{t.label}</p>
                </div>
              </div>
              <div className="flex gap-0.5 mb-4">
                {Array.from({ length: 5 }).map((_, s) => (
                  <Star key={s} className="w-4 h-4 fill-[#D4AF37] text-[#D4AF37]" />
                ))}
              </div>
              <p className="text-[#5A4A3E] text-sm leading-relaxed flex-grow">&ldquo;{t.text}&rdquo;</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}