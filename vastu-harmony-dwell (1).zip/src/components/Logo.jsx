import { Image } from '@/components/ui/image';

const LOGO_URL = 'https://media.base44.com/images/public/6a68b6c8f9de3273ba7b5fbb/a022e394c_VAASTHUSANDHYA.jpeg';

export default function Logo({ size = 50, className = '' }) {
  return (
    <div
      className={`relative flex-shrink-0 rounded-full bg-white ring-2 ring-[#F7862B]/80 p-1 shadow-[0_10px_24px_rgba(45,27,20,0.22)] ${className}`}
      style={{ width: size, height: size }}
    >
      <div className="w-full h-full rounded-full overflow-hidden bg-white">
        <Image
          src={LOGO_URL}
          alt="vaasthu sadhya logo"
          fittingType="fit"
          className="w-full h-full"
        />
      </div>
    </div>
  );
}