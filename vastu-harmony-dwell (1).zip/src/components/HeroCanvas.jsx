import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

/**
 * Lightweight WebGL hero: a faceted transmissive crystal with iridescent
 * pearlescent tint, slow continuous rotation, and mouse-parallax tracking.
 * Blends into the pearlescent background via mix-blend-multiply.
 */
export default function HeroCanvas() {
  const mountRef = useRef(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const w = () => Math.max(1, mount.clientWidth);
    const h = () => Math.max(1, mount.clientHeight);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, w() / h(), 0.1, 100);
    camera.position.set(0, 0, 5.2);

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(w(), h());
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    mount.appendChild(renderer.domElement);

    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

    // Transmissive faceted crystal
    const geo = new THREE.IcosahedronGeometry(1.5, 0);
    const mat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#F7E9C8'),
      metalness: 0.1,
      roughness: 0.05,
      transmission: 0.92,
      thickness: 0.6,
      ior: 1.52,
      clearcoat: 1,
      clearcoatRoughness: 0.1,
      iridescence: 1,
      iridescenceIOR: 1.3,
      iridescenceThicknessRange: [100, 400],
      envMapIntensity: 1.25,
      transparent: true,
    });
    const crystal = new THREE.Mesh(geo, mat);
    scene.add(crystal);

    // Gold wireframe halo shell
    const wireGeo = new THREE.IcosahedronGeometry(1.56, 0);
    const wireMat = new THREE.MeshBasicMaterial({
      color: 0xD4AF37,
      wireframe: true,
      transparent: true,
      opacity: 0.3,
      blending: THREE.AdditiveBlending,
    });
    const wire = new THREE.Mesh(wireGeo, wireMat);
    scene.add(wire);

    // Luminous core
    const coreGeo = new THREE.IcosahedronGeometry(0.5, 0);
    const coreMat = new THREE.MeshBasicMaterial({
      color: 0xFFE9A0,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
    });
    const core = new THREE.Mesh(coreGeo, coreMat);
    scene.add(core);

    scene.add(new THREE.AmbientLight(0xffffff, 0.45));
    const p1 = new THREE.PointLight(0xD4AF37, 30, 50); p1.position.set(4, 4, 4);
    const p2 = new THREE.PointLight(0x9D7BE0, 22, 50); p2.position.set(-4, -2, 3);
    const p3 = new THREE.PointLight(0xFF7B3B, 16, 50); p3.position.set(0, -4, 2);
    scene.add(p1, p2, p3);

    const target = { x: 0, y: 0 };
    const onPointer = (e) => {
      const r = mount.getBoundingClientRect();
      target.x = (e.clientX - r.left) / r.width - 0.5;
      target.y = (e.clientY - r.top) / r.height - 0.5;
    };
    window.addEventListener('pointermove', onPointer, { passive: true });

    const clock = new THREE.Clock();
    let raf;
    const tick = () => {
      const t = clock.getElapsedTime();
      crystal.rotation.x = t * 0.18 + target.y * 0.6;
      crystal.rotation.y = t * 0.26 + target.x * 0.9;
      wire.rotation.x = -t * 0.12;
      wire.rotation.y = -t * 0.18;
      core.scale.setScalar(1 + Math.sin(t * 2) * 0.12);
      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    tick();

    const onResize = () => {
      camera.aspect = w() / h();
      camera.updateProjectionMatrix();
      renderer.setSize(w(), h());
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(mount);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('pointermove', onPointer);
      ro.disconnect();
      geo.dispose();
      mat.dispose();
      wireGeo.dispose();
      wireMat.dispose();
      coreGeo.dispose();
      coreMat.dispose();
      pmrem.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="absolute inset-0 pointer-events-none mix-blend-multiply"
      aria-hidden="true"
    />
  );
}