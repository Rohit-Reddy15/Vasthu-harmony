/**
 * Mathematically precise inline SVGs for Vaastu mandalas, compasses,
 * and zodiac wheels. Hairline (0.5px) warm-gold strokes with a soft
 * ethereal feDropShadow glow.
 */

const GOLD = '#D4AF37';

function GlowDefs({ id = 'goldGlow', opacity = 0.55 }) {
  return (
    <defs>
      <filter id={id} x="-30%" y="-30%" width="160%" height="160%">
        <feDropShadow dx="0" dy="0" stdDeviation="2" floodColor={GOLD} floodOpacity={opacity} />
      </filter>
    </defs>
  );
}

export function VaastuMandalaSVG({ size = 320, className = '', rotate = false, opacity = 0.9 }) {
  const c = 450;
  const rings = [120, 220, 310, 380, 420];
  const spokes = Array.from({ length: 24 }, (_, i) => (i * 360) / 24);
  const petals = Array.from({ length: 8 }, (_, i) => (i * 360) / 8);
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 900 900"
      fill="none"
      className={`${rotate ? 'mandala-rotate ' : ''}${className}`}
      style={{ opacity }}
    >
      <GlowDefs />
      <g stroke={GOLD} strokeWidth="0.5" filter="url(#goldGlow)" transform={`translate(${c} ${c})`}>
        {rings.map((r, i) => (
          <rect key={i} x={-r} y={-r} width={r * 2} height={r * 2} />
        ))}
        <rect x={-450} y={-450} width="900" height="900" strokeWidth="0.3" />
        {spokes.map((deg, i) => {
          const rad = (deg * Math.PI) / 180;
          return <line key={i} x1="0" y1="0" x2={420 * Math.cos(rad)} y2={420 * Math.sin(rad)} strokeWidth="0.3" />;
        })}
        {[70, 45, 20].map((r) => <circle key={r} cx="0" cy="0" r={r} />)}
        {petals.map((deg, i) => {
          const rad = (deg * Math.PI) / 180;
          return (
            <ellipse
              key={i}
              cx={120 * Math.cos(rad)}
              cy={120 * Math.sin(rad)}
              rx="34"
              ry="58"
              strokeWidth="0.4"
              transform={`rotate(${deg} ${120 * Math.cos(rad)} ${120 * Math.sin(rad)})`}
            />
          );
        })}
      </g>
    </svg>
  );
}

export function CompassRoseSVG({ size = 240, className = '', opacity = 0.95 }) {
  const c = 100;
  const star = 90;
  const pts = [];
  for (let i = 0; i < 8; i += 1) {
    const ang = (i * Math.PI) / 4;
    const long = i % 2 === 0 ? 100 : 42;
    pts.push(`${long * Math.cos(ang)},${long * Math.sin(ang)}`);
  }
  const cardinals = ['N', 'E', 'S', 'W'];
  const dirs = Array.from({ length: 16 }, (_, i) => (i * 360) / 16);
  return (
    <svg width={size} height={size} viewBox="0 0 200 200" fill="none" className={className} style={{ opacity }}>
      <GlowDefs id="compassGlow" />
      <g stroke={GOLD} strokeWidth="0.5" filter="url(#compassGlow)" transform={`translate(${c} ${c})`}>
        <circle r="92" />
        <circle r="78" strokeWidth="0.3" />
        <polygon points={pts.join(' ')} strokeWidth="0.6" />
        {dirs.map((deg, i) => {
          const rad = (deg * Math.PI) / 180;
          const o = i % 4 === 0 ? 92 : 78;
          const i2 = i % 4 === 0 ? 64 : 70;
          return <line key={i} x1={o * Math.cos(rad)} y1={o * Math.sin(rad)} x2={i2 * Math.cos(rad)} y2={i2 * Math.sin(rad)} strokeWidth="0.3" />;
        })}
        <circle r="10" strokeWidth="0.6" />
        <circle r="4" />
      </g>
      <g fill={GOLD} fontFamily="Cinzel, serif" fontSize="9" textAnchor="middle" dominantBaseline="central" opacity="0.85">
        {cardinals.map((d, idx) => {
          const rad = (idx * 90 * Math.PI) / 180 - Math.PI / 2;
          return <text key={d} x={c + 88 * Math.cos(rad)} y={c + 88 * Math.sin(rad)}>{d}</text>;
        })}
      </g>
    </svg>
  );
}

export function ZodiacWheelSVG({ size = 460, className = '', rotate = false, opacity = 0.55 }) {
  const c = 250;
  const zodiac = ['Ari', 'Tau', 'Gem', 'Cnc', 'Leo', 'Vir', 'Lib', 'Sco', 'Sag', 'Cap', 'Aqr', 'Psc'];
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 500 500"
      fill="none"
      className={`${rotate ? 'mandala-rotate-rev ' : ''}${className}`}
      style={{ opacity, mixBlendMode: 'multiply' }}
    >
      <GlowDefs id="zodiacGlow" opacity={0.45} />
      <g stroke={GOLD} strokeWidth="0.5" filter="url(#zodiacGlow)" transform={`translate(${c} ${c})`}>
        <circle r="230" />
        <circle r="210" strokeWidth="0.3" />
        <circle r="150" strokeWidth="0.3" />
        <circle r="70" />
        {Array.from({ length: 12 }, (_, i) => {
          const a = (i * 30 * Math.PI) / 180;
          return (
            <line
              key={i}
              x1={70 * Math.cos(a)}
              y1={70 * Math.sin(a)}
              x2={230 * Math.cos(a)}
              y2={230 * Math.sin(a)}
              strokeWidth="0.3"
            />
          );
        })}
        {Array.from({ length: 36 }, (_, i) => {
          const a = (i * 10 * Math.PI) / 180;
          return <line key={i} x1={210 * Math.cos(a)} y1={210 * Math.sin(a)} x2={218 * Math.cos(a)} y2={218 * Math.sin(a)} strokeWidth="0.3" />;
        })}
      </g>
      <g fill={GOLD} fontFamily="Cinzel, serif" fontSize="13" textAnchor="middle" dominantBaseline="central" opacity="0.8">
        {zodiac.map((z, i) => {
          const a = (i * 30 * Math.PI) / 180 - Math.PI / 2;
          const r = 180;
          return <text key={z} x={c + r * Math.cos(a)} y={c + r * Math.sin(a)}>{z}</text>;
        })}
      </g>
    </svg>
  );
}