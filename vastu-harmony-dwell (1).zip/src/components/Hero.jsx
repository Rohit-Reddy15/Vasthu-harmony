import { Image } from '@/components/ui/image';

const HERO_IMG = 'https://media.base44.com/images/public/6a68b6c8f9de3273ba7b5fbb/81725d210_WhatsAppImage2026-08-07at114247AM.jpg';

const stats = [
  { value: '3000+', label: 'SPACES' },
  { value: '26+', label: 'YEARS' },
  { value: '100%', label: 'HARMONY' },
];

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden px-6 md:px-12 py-6 md:py-8">
      {/* Geometric pyramid/diamond wireframe behind the text */}
      <svg
        className="pointer-events-none absolute left-[8%] top-1/2 -translate-y-1/2 w-[34rem] h-[34rem] opacity-25 hidden md:block"
        viewBox="0 0 400 400"
        fill="none"
        aria-hidden="true"
      >
        <polygon points="200,30 370,200 200,370 30,200" stroke="#D4AF37" strokeWidth="0.6" />
        <polygon points="200,80 320,200 200,320 80,200" stroke="#D4AF37" strokeWidth="0.5" />
        <line x1="200" y1="30" x2="200" y2="370" stroke="#D4AF37" strokeWidth="0.4" />
        <line x1="30" y1="200" x2="370" y2="200" stroke="#D4AF37" strokeWidth="0.4" />
        <circle cx="200" cy="200" r="70" stroke="#D4AF37" strokeWidth="0.4" />
      </svg>

      <div className="relative max-w-6xl mx-auto w-full grid md:grid-cols-2 gap-6 md:gap-10 items-center">
        {/* Left — text column */}
        <div className="order-2 md:order-1 text-center md:text-left">
          <div className="inline-flex items-center gap-2 bg-[#F5EFE0] border border-[#5D4037]/25 px-4 py-2 rounded-full text-[0.7rem] font-bold text-[#8B3A1F] tracking-[0.15em] mb-6">
            <span className="w-2 h-2 rounded-full bg-[#D4AF37]" />
            INDIA&rsquo;S PREMIER ASTRO AND VAASTHU CONSULTANT
          </div>

          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold leading-[1.05] text-[#A67C46] tracking-tight">
            HARMONIZE.<br />PROSPER.<br />CELEBRATE.
          </h1>

          <p className="text-[#5E554D] text-sm md:text-[0.95rem] mt-5 max-w-md mx-auto md:mx-0 leading-relaxed">
            From grand residential floor plans to large commercial complexes &mdash; Vaasthu Sandhya Consultancy
            aligns your space with ancient Vaasthu wisdom and modern precision, delivering scientific
            remedies that transform energy and invite prosperity.
          </p>

          <div className="flex items-center justify-center md:justify-start gap-6 md:gap-10 mt-8">
            {stats.map((s, i) => (
              <div key={s.label} className="flex items-center gap-6 md:gap-10">
                {i > 0 && <span className="w-px h-10 bg-[#A6854C]/40" />}
                <div className="text-center">
                  <div className="font-display text-2xl md:text-4xl font-bold text-[#A6854C]">{s.value}</div>
                  <p className="text-[0.6rem] md:text-xs font-semibold tracking-[0.2em] text-[#5E554D] mt-1">{s.label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right — image column */}
        <div className="order-1 md:order-2 relative w-full max-w-md mx-auto aspect-[3/4]">
          <div className="absolute -inset-8 bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.18),transparent_70%)] blur-2xl pointer-events-none" />
          <div className="absolute -inset-2 border border-[#D4AF37]/45 rounded-[1.75rem] pointer-events-none" />
          <div className="absolute -inset-4 border border-[#D4AF37]/25 rounded-[2rem] pointer-events-none" />
          <div className="relative w-full h-full rounded-[1.5rem] overflow-hidden border border-[#D4AF37]/60 shadow-[0_24px_80px_rgba(45,27,20,0.28)]">
            <Image
              src={HERO_IMG}
              alt="Sri Dintakurthi Murali Krishna Guruji, founder of Vaasthu Sandhya"
              fittingType="fill"
              className="w-full h-full object-cover"
              focalPointX={0.5}
              focalPointY={0.4}
            />
          </div>
        </div>
      </div>
    </section>
  );
}